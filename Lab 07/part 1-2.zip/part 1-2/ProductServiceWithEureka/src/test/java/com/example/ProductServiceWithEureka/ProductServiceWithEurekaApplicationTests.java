package com.example.ProductServiceWithEureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductServiceWithEurekaApplicationTests {

	@Test
	void contextLoads() {
	}

}
