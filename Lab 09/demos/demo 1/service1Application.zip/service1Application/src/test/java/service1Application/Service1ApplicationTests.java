package service1Application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Service1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
